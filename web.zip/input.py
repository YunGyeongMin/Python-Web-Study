#!python
print("content-Type: text/html; charset=utf-8\n\n")

import cgi #cgi-script가 자바 서블렛처럼

data = cgi.FieldStorage(); #data 받기
print(data["txt"].value)
print(cgi.FieldStorage()["txt"].value)

with open("params.txt","a",encoding="utf8") as f:
    f.write(data["txt"].value + "\n")

html='''
<html>
    <meta http-equiv="refresh" content="0; url=index.py"></meta>
</html>
'''

print(html)

