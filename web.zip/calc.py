#!python
print("content-Type: text/html; charset=utf-8\n\n")

with open("calc.html","r",encoding="utf8") as f:
    print(f.read())